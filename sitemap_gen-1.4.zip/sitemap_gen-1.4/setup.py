#!/usr/bin/env python

from distutils.core import setup

setup(name='sitemap_gen',
      version='1.4',
      description='Sitemap Generator',
      license='BSD',
      author='Google Inc.',
      author_email='opensource@google.com',
      url='http://sourceforge.net/projects/goog-sitemapgen/',
     )
